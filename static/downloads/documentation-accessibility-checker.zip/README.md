# Documentation accessibility checker

Run the checker against rendered HTML, not source Markdown.

```bash
python3 check_documentation_accessibility.py rendered-page.html
```

The checker flags a page without exactly one `h1`, missing `alt` attributes, vague link text, heading-level jumps, tables without header cells, and code blocks (`pre` with `code`) that do not declare a language class. Inline code is not checked. It does not test keyboard behavior, contrast, zoom reflow, or screen-reader output.
